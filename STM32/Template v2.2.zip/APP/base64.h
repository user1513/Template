#ifndef _BASE64_H
#define _BASE64_H

/*base64����*/
unsigned char* base64_array_encoding(unsigned int total_size, unsigned char* scr_base, unsigned int* base64_size);


#endif

