#ifndef _BSP_EXIT_H
#define _BSP_EXIT_H

#include "driver/inc.h"

void ICACHE_FLASH_ATTR bsp_exit_init(void);

#endif